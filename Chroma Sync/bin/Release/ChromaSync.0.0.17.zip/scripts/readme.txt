﻿This folder is for LUA scripts.

For more information, visit https://github.com/UltraboxEntertainment/chromasync-sdk